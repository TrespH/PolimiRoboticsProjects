#!/bin/bash
docker network connect other-net robotics_container_pc_1
docker network connect other-net robotics_container_pc_2

